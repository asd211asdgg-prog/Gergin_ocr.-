package com.georgian.ocr

import kotlin.math.abs

/** Turns detected letter boxes into text (left-to-right, top-to-bottom). */
object TextComposer {

    // Tunable: larger => fewer spaces are inserted
    private const val LINE_TOLERANCE = 0.6f   // fraction of median letter height
    private const val SPACE_GAP = 0.7f        // fraction of median letter width

    fun compose(dets: List<Detection>): String {
        if (dets.isEmpty()) return ""

        val medH = dets.map { it.box.height() }.sorted().let { it[it.size / 2] }
        val medW = dets.map { it.box.width() }.sorted().let { it[it.size / 2] }

        // 1) group into lines
        val lines = ArrayList<MutableList<Detection>>()
        for (d in dets.sortedBy { it.box.centerY() }) {
            val cy = d.box.centerY()
            val last = lines.lastOrNull()
            if (last != null) {
                val mean = last.map { it.box.centerY() }.average().toFloat()
                if (abs(cy - mean) < medH * LINE_TOLERANCE) {
                    last.add(d)
                    continue
                }
            }
            lines.add(mutableListOf(d))
        }

        // 2) order each line left -> right and insert spaces on big gaps
        val sb = StringBuilder()
        for ((li, line) in lines.withIndex()) {
            if (li > 0) sb.append('\n')
            val ordered = line.sortedBy { it.box.centerX() }
            for ((i, d) in ordered.withIndex()) {
                if (i > 0) {
                    val gap = d.box.left - ordered[i - 1].box.right
                    if (gap > medW * SPACE_GAP) sb.append(' ')
                }
                sb.append(d.label)
            }
        }
        return sb.toString()
    }
}
