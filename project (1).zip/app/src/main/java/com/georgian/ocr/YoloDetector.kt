package com.georgian.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class Detection(val box: RectF, val cls: Int, val label: String, val score: Float)

/**
 * YOLOv8 (Ultralytics) TFLite detector.
 * Input : [1, S, S, 3] float32, RGB, 0..1
 * Output: [1, 4+nc, N] (or [1, N, 4+nc]) -> cx, cy, w, h, class scores
 */
class YoloDetector(context: Context) {

    val labels: List<String>
    val numClasses: Int

    private val interpreter: Interpreter
    private val inputSize: Int
    private val nchw: Boolean
    private val inputBuf: ByteBuffer
    private val outBuf: ByteBuffer
    private val channelsFirst: Boolean
    private val numChannels: Int
    private val numBoxes: Int

    init {
        labels = context.assets.open("labels.txt").bufferedReader(Charsets.UTF_8).readLines()
            .map { it.replace("\uFEFF", "").trim() }
            .filter { it.isNotEmpty() }

        val bytes = context.assets.open("best.tflite").use { it.readBytes() }
        val model = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        model.put(bytes)
        model.rewind()

        val options = Interpreter.Options()
        options.setNumThreads(4)
        interpreter = Interpreter(model, options)

        val inTensor = interpreter.getInputTensor(0)
        if (inTensor.dataType() != DataType.FLOAT32) {
            throw IllegalStateException("النموذج يجب أن يكون float32 أو float16 (وليس int8)")
        }
        val inShape = inTensor.shape() // [1,H,W,3] (NHWC) or [1,3,H,W] (NCHW)
        nchw = inShape.size == 4 && inShape[1] == 3 && inShape[3] != 3
        inputSize = if (nchw) inShape[2] else inShape[1]
        inputBuf = ByteBuffer.allocateDirect(4 * inputSize * inputSize * 3)
            .order(ByteOrder.nativeOrder())

        val o = interpreter.getOutputTensor(0).shape()
        channelsFirst = o[1] < o[2]
        numChannels = if (channelsFirst) o[1] else o[2]
        numBoxes = if (channelsFirst) o[2] else o[1]
        numClasses = numChannels - 4
        outBuf = ByteBuffer.allocateDirect(4 * numChannels * numBoxes)
            .order(ByteOrder.nativeOrder())
    }

    fun detect(src: Bitmap, confThr: Float = 0.25f, iouThr: Float = 0.45f): List<Detection> {
        val sw = src.width
        val sh = src.height
        val scale = min(inputSize.toFloat() / sw, inputSize.toFloat() / sh)
        val nw = (sw * scale).roundToInt()
        val nh = (sh * scale).roundToInt()
        val padX = (inputSize - nw) / 2f
        val padY = (inputSize - nh) / 2f

        // Letterbox
        val boxed = Bitmap.createBitmap(inputSize, inputSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(boxed)
        canvas.drawColor(Color.rgb(114, 114, 114))
        canvas.drawBitmap(
            src, null,
            RectF(padX, padY, padX + nw, padY + nh),
            Paint(Paint.FILTER_BITMAP_FLAG)
        )
        val pixels = IntArray(inputSize * inputSize)
        boxed.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
        boxed.recycle()

        inputBuf.rewind()
        if (nchw) {
            val plane = inputSize * inputSize
            val arr = FloatArray(3 * plane)
            for (i in 0 until plane) {
                val p = pixels[i]
                arr[i] = ((p shr 16) and 0xFF) / 255f
                arr[plane + i] = ((p shr 8) and 0xFF) / 255f
                arr[2 * plane + i] = (p and 0xFF) / 255f
            }
            inputBuf.asFloatBuffer().put(arr)
        } else {
            for (p in pixels) {
                inputBuf.putFloat(((p shr 16) and 0xFF) / 255f)
                inputBuf.putFloat(((p shr 8) and 0xFF) / 255f)
                inputBuf.putFloat((p and 0xFF) / 255f)
            }
        }
        inputBuf.rewind()
        outBuf.rewind()

        interpreter.run(inputBuf, outBuf)

        outBuf.rewind()
        val data = FloatArray(numChannels * numBoxes)
        outBuf.asFloatBuffer().get(data)

        fun v(c: Int, i: Int): Float =
            if (channelsFirst) data[c * numBoxes + i] else data[i * numChannels + c]

        // Collect candidates (raw model coordinates)
        class Raw(val cx: Float, val cy: Float, val w: Float, val h: Float, val cls: Int, val score: Float)

        val raws = ArrayList<Raw>()
        for (i in 0 until numBoxes) {
            var bestCls = -1
            var bestScore = -1f
            for (k in 0 until numClasses) {
                val s = v(4 + k, i)
                if (s > bestScore) {
                    bestScore = s
                    bestCls = k
                }
            }
            if (bestScore < confThr) continue
            raws.add(Raw(v(0, i), v(1, i), v(2, i), v(3, i), bestCls, bestScore))
        }
        if (raws.isEmpty()) return emptyList()

        // Ultralytics TFLite exports coordinates normalised to 0..1; handle pixel coords too.
        val maxCoord = raws.maxOf { max(max(it.cx, it.cy), max(it.w, it.h)) }
        val mul = if (maxCoord <= 2f) inputSize.toFloat() else 1f

        val dets = raws.map { r ->
            val cx = r.cx * mul
            val cy = r.cy * mul
            val w = r.w * mul
            val h = r.h * mul
            val x1 = ((cx - w / 2f - padX) / scale).coerceIn(0f, sw.toFloat())
            val y1 = ((cy - h / 2f - padY) / scale).coerceIn(0f, sh.toFloat())
            val x2 = ((cx + w / 2f - padX) / scale).coerceIn(0f, sw.toFloat())
            val y2 = ((cy + h / 2f - padY) / scale).coerceIn(0f, sh.toFloat())
            val name = if (r.cls < labels.size) labels[r.cls] else "#" + r.cls
            Detection(RectF(x1, y1, x2, y2), r.cls, name, r.score)
        }.filter { it.box.width() > 1f && it.box.height() > 1f }

        return nms(dets, iouThr)
    }

    private fun nms(dets: List<Detection>, iouThr: Float): List<Detection> {
        val sorted = dets.sortedByDescending { it.score }
        val keep = ArrayList<Detection>()
        for (d in sorted) {
            var ok = true
            for (k in keep) {
                if (iou(d.box, k.box) > iouThr) {
                    ok = false
                    break
                }
            }
            if (ok) keep.add(d)
        }
        return keep
    }

    private fun iou(a: RectF, b: RectF): Float {
        val l = max(a.left, b.left)
        val t = max(a.top, b.top)
        val r = min(a.right, b.right)
        val btm = min(a.bottom, b.bottom)
        val inter = max(0f, r - l) * max(0f, btm - t)
        val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }
}
