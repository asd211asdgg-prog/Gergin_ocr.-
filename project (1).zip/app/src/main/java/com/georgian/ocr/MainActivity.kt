package com.georgian.ocr

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.max

class MainActivity : Activity() {

    private companion object {
        const val REQ_PICK = 1
        const val REQ_CAMERA = 2
        const val MAX_SIDE = 2048
    }

    @Volatile
    private var detector: YoloDetector? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var cameraUri: Uri? = null
    private var lastText: String = ""

    private lateinit var statusView: TextView
    private lateinit var imageView: ImageView
    private lateinit var placeholder: TextView
    private lateinit var progress: ProgressBar
    private lateinit var resultText: TextView
    private lateinit var infoView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusView = findViewById(R.id.statusView)
        imageView = findViewById(R.id.imageView)
        placeholder = findViewById(R.id.placeholder)
        progress = findViewById(R.id.progress)
        resultText = findViewById(R.id.resultText)
        infoView = findViewById(R.id.infoView)

        findViewById<Button>(R.id.btnGallery).setOnClickListener { pickImage() }
        findViewById<Button>(R.id.btnCamera).setOnClickListener { takePhoto() }
        findViewById<Button>(R.id.btnCopy).setOnClickListener { copyText() }

        loadModel()
    }

    // ---------------------------------------------------------------- model

    private fun loadModel() {
        executor.execute {
            try {
                val d = YoloDetector(applicationContext)
                detector = d
                runOnUiThread {
                    statusView.setTextColor(getColor(R.color.green_text))
                    statusView.text = "✓ النموذج جاهز (${d.numClasses} فئة)"
                    if (d.labels.size != d.numClasses) {
                        infoView.text = "تنبيه: عدد الأسطر في labels.txt (${d.labels.size}) " +
                                "لا يساوي عدد فئات النموذج (${d.numClasses})"
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    statusView.setTextColor(getColor(R.color.red_text))
                    statusView.text = "تعذر تحميل النموذج: ${e.message}"
                }
            }
        }
    }

    // ------------------------------------------------------------ pick/camera

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        try {
            startActivityForResult(Intent.createChooser(i, "اختيار صورة"), REQ_PICK)
        } catch (e: Exception) {
            toast("لا يوجد تطبيق لاختيار الصور")
        }
    }

    private fun takePhoto() {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ocr_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                toast("تعذر تجهيز ملف الصورة")
                return
            }
            cameraUri = uri
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, uri)
            startActivityForResult(i, REQ_CAMERA)
        } catch (e: Exception) {
            toast("تعذر فتح الكاميرا: ${e.message}")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAMERA && resultCode != RESULT_OK) {
            cameraUri?.let { try { contentResolver.delete(it, null, null) } catch (e: Exception) {} }
            return
        }
        if (resultCode != RESULT_OK) return
        val uri = when (requestCode) {
            REQ_PICK -> data?.data
            REQ_CAMERA -> cameraUri
            else -> null
        } ?: return
        processImage(uri)
    }

    // -------------------------------------------------------------- inference

    private fun processImage(uri: Uri) {
        val det = detector
        if (det == null) {
            toast("النموذج غير جاهز بعد")
            return
        }
        progress.visibility = View.VISIBLE
        placeholder.visibility = View.GONE
        showResult("جاري التحليل…", isHint = true)

        executor.execute {
            try {
                val bmp = loadBitmap(uri)
                val t0 = SystemClock.elapsedRealtime()
                val dets = det.detect(bmp)
                val ms = SystemClock.elapsedRealtime() - t0
                val text = TextComposer.compose(dets)
                val annotated = drawBoxes(bmp, dets)
                runOnUiThread {
                    imageView.setImageBitmap(annotated)
                    progress.visibility = View.GONE
                    lastText = text
                    if (text.isEmpty()) {
                        showResult("لم يتم اكتشاف أي حرف. جرّب صورة أوضح.", isHint = true)
                    } else {
                        showResult(text, isHint = false)
                    }
                    infoView.text = "عدد الحروف: ${dets.size} • الزمن: $ms ms"
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    showResult("حدث خطأ: ${e.message}", isHint = true)
                }
            }
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        val source = ImageDecoder.createSource(contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val big = max(w, h)
            if (big > MAX_SIDE) {
                val f = MAX_SIDE.toFloat() / big
                decoder.setTargetSize((w * f).toInt(), (h * f).toInt())
            }
        }
    }

    private fun drawBoxes(src: Bitmap, dets: List<Detection>): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val unit = max(out.width, out.height) / 400f
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(2f, unit * 1.5f)
            color = Color.rgb(230, 160, 60)
        }
        val bgPaint = Paint().apply { color = Color.argb(210, 196, 135, 59) }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = max(14f, unit * 9f)
        }
        for (d in dets) {
            canvas.drawRect(d.box, boxPaint)
            val tw = textPaint.measureText(d.label)
            val th = textPaint.textSize
            val x = d.box.left
            val y = max(th + 2f, d.box.top)
            canvas.drawRect(x, y - th - 2f, x + tw + 8f, y + 2f, bgPaint)
            canvas.drawText(d.label, x + 4f, y - 4f, textPaint)
        }
        return out
    }

    // ------------------------------------------------------------------- ui

    private fun showResult(text: String, isHint: Boolean) {
        resultText.text = text
        if (isHint) {
            resultText.layoutDirection = View.LAYOUT_DIRECTION_RTL
            resultText.textSize = 15f
        } else {
            // Georgian is written left-to-right
            resultText.layoutDirection = View.LAYOUT_DIRECTION_LTR
            resultText.textDirection = View.TEXT_DIRECTION_LTR
            resultText.textSize = 26f
        }
    }

    private fun copyText() {
        if (lastText.isEmpty()) {
            toast("لا يوجد نص لنسخه")
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ocr", lastText))
        toast("تم نسخ النص")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
